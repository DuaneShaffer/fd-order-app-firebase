import React, { useState } from 'react';
import NewOrders from './NewOrders';
import UpdateItems from './UpdateItems';
import Warehouse from './Warehouse';
import Button from '@mui/material/Button';
import ButtonGroup from '@mui/material/ButtonGroup';

const WarehouseDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('newOrders'); // State to track active tab

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
  };

  const isActiveTab = (tab: string) => activeTab === tab;

  return (
    <div>
      <ButtonGroup variant="contained" aria-label="outlined primary button group">
        <Button
          variant={isActiveTab('newOrders') ? 'contained' : 'outlined'}
          color="primary"
          onClick={() => handleTabChange('newOrders')}
        >
          New Orders
        </Button>
        <Button
          variant={isActiveTab('updateItems') ? 'contained' : 'outlined'}
          color="primary"
          onClick={() => handleTabChange('updateItems')}
        >
          Update Items
        </Button>
        <Button
          variant={isActiveTab('warehouse') ? 'contained' : 'outlined'}
          color="primary"
          onClick={() => handleTabChange('warehouse')}
        >
          Warehouse
        </Button>
      </ButtonGroup>
      <div style={{ marginTop: '20px' }}>
        {activeTab === 'newOrders' && <NewOrders />}
        {activeTab === 'updateItems' && <UpdateItems />}
        {activeTab === 'warehouse' && <Warehouse />}
      </div>
    </div>
  );
};

export default WarehouseDashboard;
