import React, { useEffect, useState } from 'react';
import { db } from '../firebase';
import { collection, doc, getDocs, updateDoc, addDoc, QuerySnapshot, DocumentData } from 'firebase/firestore';
import { Item, AttributeHistory } from '../models/Item';

const UpdateItems: React.FC = () => {
    const [items, setItems] = useState<Item[]>([]);
    const [editItem, setEditItem] = useState<Item | null>(null);
    const [newDetails, setNewDetails] = useState<Partial<Item>>({
        name: '',
        category: '',
        subcategory: '',
        attributes: {
            caseSize: 0,
            upc: '',
            weight: 0,
            history: []
        },
        isActive: false,
        isInAndOut: false
    });
    const [isEditing, setIsEditing] = useState(false); // Track whether in edit or insert mode

    useEffect(() => {
        const fetchItems = async () => {
            const querySnapshot: QuerySnapshot<DocumentData> = await getDocs(collection(db, 'items'));
            const itemsArray: Item[] = [];
            querySnapshot.forEach((doc) => {
                itemsArray.push({ id: doc.id, ...doc.data() } as Item);
            });
            setItems(itemsArray);
        };

        fetchItems();
    }, []);

    const handleEditClick = (item: Item) => {
        setEditItem(item);
        setNewDetails({
            name: item.name,
            category: item.category,
            subcategory: item.subcategory,
            attributes: {
                caseSize: item.attributes.caseSize,
                upc: item.attributes.upc || '',
                weight: item.attributes.weight,
                history: item.attributes.history || [],
            },
            isActive: item.isActive,
            isInAndOut: item.isInAndOut,
        });
        setIsEditing(true);
    };

    const handleSaveClick = async () => {
        if (isEditing && editItem) {
            const itemDoc = doc(db, 'items', editItem.id);
            await updateDoc(itemDoc, { ...newDetails });
            setEditItem(null);
            setIsEditing(false);
        } else {
            // Insert new item
            const newItemRef = await addDoc(collection(db, 'items'), newDetails);
            setItems([...items, { id: newItemRef.id, ...newDetails } as Item]);
            setNewDetails({
                name: '',
                category: '',
                subcategory: '',
                attributes: {
                    caseSize: 0,
                    upc: '',
                    weight: 0,
                    history: []
                },
                isActive: false,
                isInAndOut: false
            });
        }
    };

    const handleInsertClick = () => {
        setEditItem(null);
        setNewDetails({
            name: '',
            category: '',
            subcategory: '',
            attributes: {
                caseSize: 0,
                upc: '',
                weight: 0,
                history: []
            },
            isActive: false,
            isInAndOut: false
        });
        setIsEditing(false);
    };

    return (
        <div>
            <h2>{isEditing ? 'Edit Item' : 'Update Items'}</h2>
            <ul>
                {items.map((item) => (
                    <li key={item.id}>
                        {item.name} - Category: {item.category} - Subcategory: {item.subcategory} -
                        Case Size: {item.attributes.caseSize} - UPC: {item.attributes.upc} -
                        Weight: {item.attributes.weight}
                        <button onClick={() => handleEditClick(item)}>Edit</button>
                    </li>
                ))}
            </ul>

            {!isEditing && (
                <button onClick={handleInsertClick}>Insert New Item</button>
            )}

            {(!isEditing || editItem) && (
                <div>
                    <h3>{isEditing ? 'Edit Item' : 'Insert New Item'}</h3>
                    <label>
                        Name:
                        <input
                            type="text"
                            value={newDetails.name || ''}
                            onChange={(e) => setNewDetails({ ...newDetails, name: e.target.value })}
                        />
                    </label>
                    <br />
                    <label>
                        Category:
                        <input
                            type="text"
                            value={newDetails.category || ''}
                            onChange={(e) => setNewDetails({ ...newDetails, category: e.target.value })}
                        />
                    </label>
                    <br />
                    <label>
                        Subcategory:
                        <input
                            type="text"
                            value={newDetails.subcategory || ''}
                            onChange={(e) => setNewDetails({ ...newDetails, subcategory: e.target.value })}
                        />
                    </label>
                    <br />
                    <label>
                        Case Size:
                        <input
                            type="number"
                            value={newDetails.attributes?.caseSize ?? ''}
                            onChange={(e) =>
                                setNewDetails({
                                    ...newDetails,
                                    attributes: {
                                        ...newDetails.attributes!,
                                        caseSize: parseInt(e.target.value)
                                    }
                                })
                            }
                        />
                    </label>
                    <br />
                    <label>
                        UPC:
                        <input
                            type="text"
                            value={newDetails.attributes?.upc || ''}
                            onChange={(e) =>
                                setNewDetails({
                                    ...newDetails,
                                    attributes: {
                                        ...newDetails.attributes!,
                                        upc: e.target.value
                                    }
                                })
                            }
                        />
                    </label>
                    <br />
                    <label>
                        Weight:
                        <input
                            type="number"
                            value={newDetails.attributes?.weight ?? ''}
                            onChange={(e) =>
                                setNewDetails({
                                    ...newDetails,
                                    attributes: {
                                        ...newDetails.attributes!,
                                        weight: parseInt(e.target.value)
                                    }
                                })
                            }
                        />
                    </label>
                    <br />
                    <label>
                        Active:
                        <input
                            type="checkbox"
                            checked={newDetails.isActive || false}
                            onChange={(e) => setNewDetails({ ...newDetails, isActive: e.target.checked })}
                        />
                    </label>
                    <br />
                    <label>
                        In and Out:
                        <input
                            type="checkbox"
                            checked={newDetails.isInAndOut || false}
                            onChange={(e) => setNewDetails({ ...newDetails, isInAndOut: e.target.checked })}
                        />
                    </label>
                    <br />
                    <button onClick={handleSaveClick}>{isEditing ? 'Save' : 'Insert'}</button>
                    {isEditing && <button onClick={() => { setEditItem(null); setIsEditing(false); }}>Cancel</button>}
                </div>
            )}
        </div>
    );
};

export default UpdateItems;
