declare module 'quagga';
