var admin = require("firebase-admin");

var serviceAccount = require("/mnt/c/Users/dlshaffer/Downloads/fd-order-app-firebase-adminsdk-254qw-bf28bd1edb.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});


const uid = 'tH4AMmiFAbgGqnIMWIUn8XFWnsc2'; // Replace with the UID of the user you want to make admin

// Set custom claim to make user an admin
admin.auth().setCustomUserClaims(uid, { admin: true })
  .then(() => {
    console.log('Custom claim set for user');
  })
  .catch((error) => {
    console.error('Error setting custom claim:', error);
  });

